<?php
/**
* template Name:Home
* template post type: page
*
* @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Personal_Info_by_SpiderBuzz
 */
?>
<?php get_header(); ?>
			
<?php get_footer(); ?>